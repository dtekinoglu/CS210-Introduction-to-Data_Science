/*package com.company;

import java.util.Random;

public class kayıt {
}

    public void run() {
        int count = 0;


        while (count <=N){
            if (id!=4) barriers[id + 1].release();
            else barriers[0].release();
            try {
                barriers[id].acquire();
                table.PutPlate_GUI(id);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            count++;
        }


        table.StartDining_GUI(id);

        // this part is for taking forks.
        while (true) {
            if (state[id] != HUNGRY)
                state[id] = THINKING;
            Random random = new Random();
            int thinkingTime = 1;
            thinkingTime = random.nextInt(11);
            //System.out.print(thinkingTime);
            //System.out.println("  ");
            try {
                sleep(thinkingTime * 1000);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            state[id] = HUNGRY;
            table.Hungry_GUI(id);
            try {
                mutex.acquire(); //exception handle
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (state[id] == HUNGRY && state[(id + N - 1) % N] != EATING && state[(id + 1) % N] != EATING) {
                state[id] = EATING;
                table.ForkTake_GUI(id);
                table.Eating_GUI(id);
                sem[id].release();

                try {
                    sem[id].acquire();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            mutex.release();

            if (state[id] == EATING) {
                try {
                    mutex.acquire();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                table.StopEating_GUI(id);
                table.ForkPut_GUI(id);
                state[id] = THINKING;
                mutex.release();
            }
            try {
                mutex.acquire();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            int left = (id + N - 1) % N;
            int right = (id + 1) % N;
            if (state[left] == HUNGRY && state[(left + N - 1) % N] != EATING && state[(left + 1) % N] != EATING) {
                sem[left].release();
                table.ForkTake_GUI(left);
                table.Eating_GUI(left);
                state[left] = EATING;

            }
            if (state[right] == HUNGRY && state[(right + N - 1) % N] != EATING && state[(right + 1) % N] != EATING) {
                sem[right].release();
                state[right] = EATING;
                table.ForkTake_GUI(left);
                table.Eating_GUI(left);
            }
            mutex.release();
        }
    }
}*/